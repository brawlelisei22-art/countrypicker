package dev.policraft.countrypicker;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CountryPicker extends JavaPlugin implements Listener {

    private File dataFile;
    private YamlConfiguration data;                         // player UUID -> country id
    private final Map<UUID, Long> lastMessage = new HashMap<>(); // anti-spam for chat messages

    @Override
    public void onEnable() {
        saveDefaultConfig(); // copies config.yml from the jar on first start
        dataFile = new File(getDataFolder(), "players.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("countryreset") != null) {
            getCommand("countryreset").setExecutor(this);
        }
    }

    // ---------------------------------------------------------------- click on the hub map

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        // The event fires once per hand, so only handle the main hand.
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        // Picking needs an empty hand, so admins can still build the map with blocks.
        if (event.getItem() != null) return;

        Block block = event.getClickedBlock();
        if (block == null) return;
        if (!block.getWorld().getName().equals(getConfig().getString("world", "world"))) return;

        String countryId = findCountryAt(block.getX(), block.getZ());
        if (countryId == null) return;

        event.setCancelled(true);
        Player player = event.getPlayer();

        if (hasCountry(player)) {
            notify(player, "Ты уже выбрал страну.");
            return;
        }

        int max = getConfig().getInt("max-players-per-country", 3);
        if (countPlayers(countryId) >= max) {
            notify(player, "В этой стране уже нет мест. Выбери другую.");
            return;
        }

        joinCountry(player, countryId);
    }

    private void joinCountry(Player player, String countryId) {
        ConfigurationSection country = getConfig().getConfigurationSection("countries." + countryId);
        if (country == null) return;

        World world = getServer().getWorld(getConfig().getString("world", "world"));
        ConfigurationSection s = country.getConfigurationSection("spawn");
        if (world == null || s == null) {
            player.sendMessage("Ошибка настройки спавна. Сообщи админу.");
            getLogger().warning("Missing world or spawn for country " + countryId);
            return;
        }
        Location spawn = new Location(world, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), 0f);

        // Remember the choice first, so a crash later cannot give a second pick.
        data.set(player.getUniqueId().toString(), countryId);
        saveData();

        // Put the player into the LuckPerms group (TAB shows the flag from it).
        String group = country.getString("group", countryId);
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                "lp user " + player.getName() + " parent set " + group);

        player.teleport(spawn);
        setRespawn(player, spawn);
        giveKit(player, country.getStringList("kit"));
        player.sendMessage("Ты теперь представляешь страну: " + country.getString("name", countryId) + "!");
    }

    @SuppressWarnings("deprecation")
    private void setRespawn(Player player, Location spawn) {
        // true = keep this respawn point even without a bed
        player.setBedSpawnLocation(spawn, true);
    }

    private void giveKit(Player player, List<String> kit) {
        for (String entry : kit) {
            String[] parts = entry.split(":");
            Material material = Material.matchMaterial(parts[0].trim());
            if (material == null) {
                getLogger().warning("Unknown material in kit: " + parts[0]);
                continue;
            }
            int amount = 1;
            if (parts.length > 1) {
                try {
                    amount = Integer.parseInt(parts[1].trim());
                } catch (NumberFormatException e) {
                    getLogger().warning("Bad amount in kit entry: " + entry);
                }
            }
            // addItem returns whatever did not fit; drop it at the player's feet.
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack(material, amount));
            for (ItemStack rest : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), rest);
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private String findCountryAt(int x, int z) {
        ConfigurationSection all = getConfig().getConfigurationSection("countries");
        if (all == null) return null;
        for (String id : all.getKeys(false)) {
            ConfigurationSection a = all.getConfigurationSection(id + ".map-area");
            if (a == null) continue;
            int minX = Math.min(a.getInt("x1"), a.getInt("x2"));
            int maxX = Math.max(a.getInt("x1"), a.getInt("x2"));
            int minZ = Math.min(a.getInt("z1"), a.getInt("z2"));
            int maxZ = Math.max(a.getInt("z1"), a.getInt("z2"));
            if (x >= minX && x <= maxX && z >= minZ && z <= maxZ) return id;
        }
        return null;
    }

    private boolean hasCountry(Player player) {
        if (data.contains(player.getUniqueId().toString())) return true;
        // Also catches players an admin put into a country group by hand.
        ConfigurationSection all = getConfig().getConfigurationSection("countries");
        if (all == null) return false;
        for (String id : all.getKeys(false)) {
            String group = all.getString(id + ".group", id);
            if (player.hasPermission("group." + group)) return true;
        }
        return false;
    }

    private int countPlayers(String countryId) {
        int count = 0;
        for (String key : data.getKeys(false)) {
            if (countryId.equals(data.getString(key))) count++;
        }
        return count;
    }

    private void notify(Player player, String message) {
        long now = System.currentTimeMillis();
        Long last = lastMessage.get(player.getUniqueId());
        if (last != null && now - last < 3000) return;
        lastMessage.put(player.getUniqueId(), now);
        player.sendMessage(message);
    }

    private void saveData() {
        try {
            data.save(dataFile);
        } catch (IOException e) {
            getLogger().severe("Could not save players.yml: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------- /countryreset <player>

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length != 1) {
            sender.sendMessage("Использование: /countryreset <ник>");
            return true;
        }
        @SuppressWarnings("deprecation")
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        data.set(target.getUniqueId().toString(), null);
        saveData();
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + args[0] + " parent set default");
        sender.sendMessage("Выбор страны сброшен для " + args[0] + ". Предметы и точка возрождения не меняются.");
        return true;
    }
}
